<?php

namespace App\Http\Controllers\Cusoter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AccountController extends Controller
{
    //
}
