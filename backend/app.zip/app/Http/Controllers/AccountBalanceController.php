<?php

namespace App\Http\Controllers;

use App\Models\AccountBalance;
use Illuminate\Http\Request;

class AccountBalanceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\AccountBalance  $accountBalance
     * @return \Illuminate\Http\Response
     */
    public function show(AccountBalance $accountBalance)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\AccountBalance  $accountBalance
     * @return \Illuminate\Http\Response
     */
    public function edit(AccountBalance $accountBalance)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\AccountBalance  $accountBalance
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AccountBalance $accountBalance)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\AccountBalance  $accountBalance
     * @return \Illuminate\Http\Response
     */
    public function destroy(AccountBalance $accountBalance)
    {
        //
    }
}
