<?php echo e($slot); ?>

<?php /**PATH /home/cbcholdi/public_html/bank/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>