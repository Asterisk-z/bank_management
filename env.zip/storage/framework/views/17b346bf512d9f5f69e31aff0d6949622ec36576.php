<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4 col-lg-3">
		<ul class="nav flex-column nav-tabs settings-tab" role="tablist">
			 <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#account_overview"><i class="icofont-ui-user"></i> <?php echo e(_lang('Account Overview')); ?></a></li>
			 <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#transactions"><i class="icofont-listine-dots"></i><?php echo e(_lang('Transactions')); ?></a></li>
			 <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#add_money"><i class="icofont-plus-circle"></i> <?php echo e(_lang('Add Money')); ?></a></li>
			 <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#deduct_money"><i class="icofont-minus-circle"></i> <?php echo e(_lang('Deduct Money')); ?></a></li>
			 <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#my_loans"><i class="icofont-bank"></i> <?php echo e(_lang('Loans')); ?></a></li>
			 <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#my_fdr"><i class="icofont-money"></i> <?php echo e(_lang('Fixed Deposit')); ?></a></li>
			 <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#support_tickets"><i class="icofont-live-support"></i> <?php echo e(_lang('Support Ticket')); ?></a></li>
             <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#email"><i class="icofont-email"></i> <?php echo e(_lang('Send Email')); ?></a></li>
             <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#sms"><i class="icofont-email"></i> <?php echo e(_lang('Send SMS')); ?></a></li>
		</ul>
	</div>

    <div class="col-md-8 col-lg-9">
        <div class="tab-content">
			<div id="account_overview" class="tab-pane active">
                <div class="card">
                    <div class="card-header">
                        <span class="header-title"><?php echo e(_lang('User Details')); ?></span>
                    </div>

                    <div class="card-body">
                        <table class="table table-bordered">
                            <tr>
                                <td colspan="2" class="text-center"><img class="thumb-image-sm img-thumbnail"
                                        src="<?php echo e(profile_picture($user->profile_picture)); ?>"></td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <div class="row">
                                        <?php $__currentLoopData = $account_balance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md">
                                            <div class="card mb-4">
                                                <div class="card-body">
                                                    <h6><?php echo e($currency->name.' '._lang('Balance')); ?></h6>
                                                    <h6 class="pt-1"><b><?php echo e(decimalPlace($currency->balance, currency($currency->name))); ?></b></h6>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td><?php echo e(_lang('Name')); ?></td>
                                <td><?php echo e($user->name); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(_lang('Account Number')); ?></td>
                                <td><?php echo e($user->account_number); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(_lang('Email')); ?></td>
                                <td><?php echo e($user->email); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(_lang('Phone')); ?></td>
                                <td><?php echo e('+'.$user->country_code.'-'.$user->phone); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(_lang('Branch')); ?></td>
                                <td><?php echo e($user->branch->name); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(_lang('Status')); ?></td>
                                <td><?php echo xss_clean(status($user->status)); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(_lang('Email Verified')); ?></td>
                                <td><?php echo $user->email_verified_at != null ? xss_clean(show_status(_lang('Yes'),'primary')) : xss_clean(show_status(_lang('No'),'danger')); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(_lang('SMS Verified')); ?></td>
                                <td><?php echo $user->sms_verified_at != null ? xss_clean(show_status(_lang('Yes'),'primary')) : xss_clean(show_status(_lang('No'),'danger')); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(_lang('Withdraw Money')); ?></td>
                                <td><?php echo $user->allow_withdrawal == 1 ? xss_clean(show_status(_lang('Allowed'),'primary')) : xss_clean(show_status(_lang('Not Allowed'),'danger')); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(_lang('Account Opening Date')); ?></td>
                                <td><?php echo e($user->created_at); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div><!--End account overview Tab-->

            <div id="transactions" class="tab-pane">
                <div class="card">
                    <div class="card-header">
                        <span class="header-title"><?php echo e(_lang('Transactions')); ?></span>
                    </div>

                    <div class="card-body">
                        <table class="table table-bordered data-table">
                            <thead>
                                <tr>
                                    <th><?php echo e(_lang('Date')); ?></th>
                                    <th><?php echo e(_lang('Currency')); ?></th>
                                    <th><?php echo e(_lang('Amount')); ?></th>
                                    <th><?php echo e(_lang('Charge')); ?></th>
                                    <th><?php echo e(_lang('Grand Total')); ?></th>
                                    <th><?php echo e(_lang('DR/CR')); ?></th>
                                    <th><?php echo e(_lang('Type')); ?></th>
                                    <th><?php echo e(_lang('Status')); ?></th>
                                    <th><?php echo e(_lang('Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $user->transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $symbol = $transaction->dr_cr == 'dr' ? '-' : '+';
                                $class  = $transaction->dr_cr == 'dr' ? 'text-danger' : 'text-success';
                                ?>
                                <tr>
                                    <td><?php echo e($transaction->created_at); ?></td>
                                    <td><?php echo e($transaction->currency->name); ?></td>
                                    <?php if($transaction->dr_cr == 'dr'): ?>
                                    <td><?php echo e(decimalPlace(($transaction->amount - $transaction->fee), currency($transaction->currency->name))); ?></td>
                                    <?php else: ?>
                                    <td><?php echo e(decimalPlace(($transaction->amount + $transaction->fee), currency($transaction->currency->name))); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($transaction->dr_cr == 'dr' ? '+ '.decimalPlace($transaction->fee, currency($transaction->currency->name)) : '- '.decimalPlace($transaction->fee, currency($transaction->currency->name))); ?></td>
                                    <td><span class="<?php echo e($class); ?>"><?php echo e($symbol.' '.decimalPlace($transaction->amount, currency($transaction->currency->name))); ?></span></td>
                                    <td><?php echo e(strtoupper($transaction->dr_cr)); ?></td>
                                    <td><?php echo e(str_replace('_',' ',$transaction->type)); ?></td>
                                    <td><?php echo xss_clean(transaction_status($transaction->status)); ?></td>
                                    <td><a href="<?php echo e(action('TransferRequestController@show', $transaction['id'])); ?>" data-title="<?php echo e(_lang('Transaction Details')); ?>" class="btn btn-outline-primary btn-sm ajax-modal"><i class="icofont-eye-alt"></i> <?php echo e(_lang('Details')); ?></a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div><!--End Transaction Tab-->

            <div id="add_money" class="tab-pane">
                <div class="card">
                    <div class="card-header">
                        <span class="header-title"><?php echo e(_lang('Add Money')); ?></span>
                    </div>

                    <div class="card-body">
                        <form method="post" class="validate" autocomplete="off" action="<?php echo e(route('deposits.store')); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label"><?php echo e(_lang('User Email')); ?></label>
                                        <input type="email" class="form-control" name="account_number" value="<?php echo e($user->email); ?>" required="" readonly>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label"><?php echo e(_lang('Date')); ?></label>
                                        <input type="text" class="form-control datetimepicker" name="date" value="<?php echo e(old('date')); ?>" required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label"><?php echo e(_lang('Currency')); ?></label>
                                        <select class="form-control auto-select select2" data-selected="<?php echo e(old('currency_id')); ?>" name="currency_id" required>
                                            <option value=""><?php echo e(_lang('Select One')); ?></option>
                                            <?php echo e(create_option('currency','id','name','',array('status=' => 1))); ?>

                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label"><?php echo e(_lang('Amount')); ?></label>
                                        <input type="text" class="form-control float-field" name="amount" value="<?php echo e(old('amount')); ?>" required>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label"><?php echo e(_lang('Note')); ?></label>
                                        <textarea class="form-control" name="note"><?php echo e(old('note')); ?></textarea>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary btn-lg"><i class="icofont-check-circled"></i> <?php echo e(_lang('Submit')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div><!--End Add Money Tab-->

            <div id="deduct_money" class="tab-pane">
                <div class="card">
                    <div class="card-header">
                        <span class="header-title"><?php echo e(_lang('Deduct Money')); ?></span>
                    </div>

                    <div class="card-body">
                        <form method="post" class="validate" autocomplete="off" action="<?php echo e(route('withdraw.store')); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label"><?php echo e(_lang('User Email')); ?></label>
                                        <input type="email" class="form-control" name="account_number" value="<?php echo e($user->email); ?>" required="" readonly>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label"><?php echo e(_lang('Date')); ?></label>
                                        <input type="text" class="form-control datetimepicker" name="date" value="<?php echo e(old('date')); ?>" required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label"><?php echo e(_lang('Currency')); ?></label>
                                        <select class="form-control auto-select select2" data-selected="<?php echo e(old('currency_id')); ?>" name="currency_id" required>
                                            <option value=""><?php echo e(_lang('Select One')); ?></option>
                                            <?php echo e(create_option('currency','id','name','',array('status=' => 1))); ?>

                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label"><?php echo e(_lang('Amount')); ?></label>
                                        <input type="text" class="form-control float-field" name="amount" value="<?php echo e(old('amount')); ?>" required>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label"><?php echo e(_lang('Note')); ?></label>
                                        <textarea class="form-control" name="note"><?php echo e(old('note')); ?></textarea>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary btn-lg"><i class="icofont-check-circled"></i> <?php echo e(_lang('Submit')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div><!--End Add Money Tab-->

            <div id="my_loans" class="tab-pane">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span class="panel-title"><?php echo e(_lang('Loans')); ?></span>
                        <a class="btn btn-primary btn-sm float-right" href="<?php echo e(route('loans.create')); ?>"><i class="icofont-plus-circle"></i> <?php echo e(_lang('Add New Loan')); ?></a>
                    </div>

                    <div class="card-body">
                        <table id="loans_table" class="table table-bordered data-table">
                            <thead>
                                <tr>
                                    <th><?php echo e(_lang('Loan ID')); ?></th>
                                    <th><?php echo e(_lang('Loan Product')); ?></th>
                                    <th class="text-right"><?php echo e(_lang('Applied Amount')); ?></th>
                                    <th class="text-right"><?php echo e(_lang('Total Payable')); ?></th>
                                    <th class="text-right"><?php echo e(_lang('Amount Paid')); ?></th>
                                    <th class="text-right"><?php echo e(_lang('Due Amount')); ?></th>
                                    <th><?php echo e(_lang('Release Date')); ?></th>
                                    <th><?php echo e(_lang('Status')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $user->loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(route('loans.show',$loan->id)); ?>"><?php echo e($loan->loan_id); ?></a></td>
                                    <td><?php echo e($loan->loan_product->name); ?></td>
                                    <td class="text-right"><?php echo e(decimalPlace($loan->applied_amount, currency($loan->currency->name))); ?></td>
                                    <td class="text-right"><?php echo e(decimalPlace($loan->total_payable, currency($loan->currency->name))); ?></td>
                                    <td class="text-right"><?php echo e(decimalPlace($loan->total_paid, currency($loan->currency->name))); ?></td>
                                    <td class="text-right"><?php echo e(decimalPlace($loan->total_payable - $loan->total_paid, currency($loan->currency->name))); ?></td>
                                    <td><?php echo e($loan->release_date); ?></td>
                                    <td>
                                        <?php if($loan->status == 0): ?>
                                            <?php echo xss_clean(show_status(_lang('Pending'), 'warning')); ?>

                                        <?php elseif($loan->status == 1): ?>
                                            <?php echo xss_clean(show_status(_lang('Approved'), 'success')); ?>

                                        <?php elseif($loan->status == 2): ?>
                                            <?php echo xss_clean(show_status(_lang('Completed'), 'info')); ?>

                                        <?php elseif($loan->status == 3): ?>
                                            <?php echo xss_clean(show_status(_lang('Cancelled'), 'danger')); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div><!--End Send Email Tab-->

            <div id="my_fdr" class="tab-pane">
                <div class="card">
                    <div class="card-header">
                        <span class="header-title"><?php echo e(_lang('Fixed Deposit')); ?></span>
                    </div>

                    <div class="card-body">
                        <table id="fdr_table" class="table table-bordered data-table">
                            <thead>
                                <tr>
                                    <th><?php echo e(_lang('Plan')); ?></th>
                                    <th><?php echo e(_lang('Currency')); ?></th>
                                    <th><?php echo e(_lang('Deposit Amount')); ?></th>
                                    <th><?php echo e(_lang('Return Amount')); ?></th>
                                    <th><?php echo e(_lang('Status')); ?></th>
                                    <th><?php echo e(_lang('Mature Date')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $user->fixed_deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fixed_deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($fixed_deposit->plan->name); ?></td>
                                    <td><?php echo e($fixed_deposit->currency->name); ?></td>
                                    <td><?php echo e(decimalPlace($fixed_deposit->deposit_amount, currency($fixed_deposit->currency->name))); ?></td>
                                    <td><?php echo e(decimalPlace($fixed_deposit->return_amount, currency($fixed_deposit->currency->name))); ?></td>
                                    <td><?php echo xss_clean(fdr_status($fixed_deposit->status)); ?></td>
                                    <td><?php echo e($fixed_deposit->mature_date); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div><!--End Fixed Deposit Tab-->

            <div id="support_tickets" class="tab-pane">
                <div class="card">
                    <div class="card-header">
                        <span class="header-title"><?php echo e(_lang('Support Tickets')); ?></span>
                    </div>

                    <div class="card-body">
                        <table id="support_tickets_table" class="table table-bordered data-table">
                            <thead>
                                <tr>
                                    <th><?php echo e(_lang('ID')); ?></th>
                                    <th><?php echo e(_lang('Subject')); ?></th>
                                    <th><?php echo e(_lang('Status')); ?></th>
                                    <th><?php echo e(_lang('Created')); ?></th>
                                    <th class="text-center"><?php echo e(_lang('Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $user->support_tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supportticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($supportticket->id); ?></td>
                                    <td><?php echo e($supportticket->subject); ?></td>
                                    <td><?php echo xss_clean(ticket_status($supportticket->status)); ?></td>
                                    <td><?php echo e($supportticket->created_at); ?></td>
                                    <td class="text-center">
                                        <a href="<?php echo e(action('SupportTicketController@show', $supportticket['id'])); ?>" class="btn btn-primary btn-sm"><i class="icofont-ui-messaging"></i> <?php echo e(_lang('View Conversations')); ?></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div><!--End Support ticket Tab-->

            <div id="email" class="tab-pane">
                <div class="card">
                    <div class="card-header">
                        <span class="header-title"><?php echo e(_lang('Send Email')); ?></span>
                    </div>

                    <div class="card-body">
                        <form method="post" class="validate" autocomplete="off" action="<?php echo e(route('users.send_email')); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label"><?php echo e(_lang('User Email')); ?></label>
                                        <input type="email" class="form-control" name="user_email" value="<?php echo e($user->email); ?>" required="" readonly>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label"><?php echo e(_lang('Subject')); ?></label>
                                        <input type="text" class="form-control" name="subject" value="<?php echo e(old('subject')); ?>" required>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label"><?php echo e(_lang('Message')); ?></label>
                                        <textarea class="form-control" rows="8" name="message" required><?php echo e(old('message')); ?></textarea>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary btn-block"><i class="icofont-check-circled"></i> <?php echo e(_lang('Send')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div><!--End Send Email Tab-->

            <div id="sms" class="tab-pane">
                <div class="card">
                    <div class="card-header">
                        <span class="header-title"><?php echo e(_lang('Send SMS')); ?></span>
                    </div>

                    <div class="card-body">
                    <form method="post" class="validate" autocomplete="off" action="<?php echo e(route('users.send_sms')); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label"><?php echo e(_lang('User Mobile')); ?></label>
                                        <input type="text" class="form-control" name="phone" value="<?php echo e('+'.$user->country_code.$user->phone); ?>" required="" readonly>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label"><?php echo e(_lang('Message')); ?></label>
                                        <textarea class="form-control" name="message" required><?php echo e(old('message')); ?></textarea>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary btn-block"><i class="icofont-check-circled"></i> <?php echo e(_lang('Send')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div><!--End Send SMS Tab-->

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-script'); ?>
<script>
   (function($) {
       "use strict";

   	$('.nav-tabs a').on('shown.bs.tab', function(event){
   		var tab = $(event.target).attr("href");
   		var url = "<?php echo e(route('users.show',$user->id)); ?>";
   	    history.pushState({}, null, url + "?tab=" + tab.substring(1));
   	});

   	<?php if(isset($_GET['tab'])): ?>
   	   $('.nav-tabs a[href="#<?php echo e($_GET['tab']); ?>"]').tab('show');
   	<?php endif; ?>

    $("a[data-toggle=\"tab\"]").on("shown.bs.tab", function (e) {
        $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
    });

   })(jQuery);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cbcholdi/public_html/bank/resources/views/backend/user/view.blade.php ENDPATH**/ ?>