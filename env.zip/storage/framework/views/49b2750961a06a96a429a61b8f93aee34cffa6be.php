<table class="table table-bordered">
	<tr><td><?php echo e(_lang('Name')); ?></td><td><?php echo e($otherbank->name); ?></td></tr>
	<tr><td><?php echo e(_lang('Swift Code')); ?></td><td><?php echo e($otherbank->swift_code); ?></td></tr>
	<tr><td><?php echo e(_lang('Bank Country')); ?></td><td><?php echo e($otherbank->bank_country); ?></td></tr>
	<tr><td><?php echo e(_lang('Bank Currency')); ?></td><td><?php echo e($otherbank->currency->name); ?></td></tr>
	<tr><td><?php echo e(_lang('Minimum Transfer Amount')); ?></td><td><?php echo e(currency($otherbank->currency->name).' '.$otherbank->minimum_transfer_amount); ?></td></tr>
	<tr><td><?php echo e(_lang('Maximum Transfer Amount')); ?></td><td><?php echo e(currency($otherbank->currency->name).' '.$otherbank->maximum_transfer_amount); ?></td></tr>
	<tr><td><?php echo e(_lang('Fixed Charge')); ?></td><td><?php echo e(currency($otherbank->currency->name).' '.$otherbank->fixed_charge); ?></td></tr>
	<tr><td><?php echo e(_lang('Charge In Percentage')); ?></td><td><?php echo e($otherbank->charge_in_percentage.' %'); ?></td></tr>
	<tr><td><?php echo e(_lang('Instructions')); ?></td><td><?php echo e($otherbank->descriptions); ?></td></tr>
	<tr><td><?php echo e(_lang('Status')); ?></td><td><?php echo xss_clean(status($otherbank->status)); ?></td></tr>
</table>

<?php /**PATH /home/cbcholdi/public_html/bank/resources/views/backend/other_bank/modal/view.blade.php ENDPATH**/ ?>