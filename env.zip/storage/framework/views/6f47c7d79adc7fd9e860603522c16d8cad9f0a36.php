<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-6 offset-lg-3">
		<div class="card">
			<div class="card-header">
				<h4 class="header-title text-center"><?php echo e(_lang('Verify OTP')); ?></h4>
			</div>
			<div class="card-body">
			    <form method="post" class="validate" autocomplete="off" action="<?php echo e(session('action')); ?>" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>


					<div class="alert alert-info" role="alert">
						<?php echo e(_lang('OTP has been sent to your email address. Please check your email')); ?>

					</div>

					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label class="control-label"><?php echo e(_lang('ENTER OTP')); ?></label>
								<input type="text" class="form-control" name="otp" value="<?php echo e(old('otp')); ?>" required>
							</div>
						</div>

						<div class="col-md-12 mt-4">
							<div class="form-group">
								<button type="submit" class="btn btn-primary btn-lg btn-block"><i class="icofont-check-circled"></i> <?php echo e(_lang('Submit')); ?></button>
							</div>
						</div>

						<div class="col-12 text-center">
							<a href="<?php echo e(route('otp.resend')); ?>" class="btn-link"><?php echo e(_lang('Resend OTP Code')); ?></a>
						</div>
					</div>
			    </form>
			</div>
		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cbcholdi/public_html/bank/resources/views/backend/customer_portal/otp/show.blade.php ENDPATH**/ ?>