<form method="post" class="ajax-screen-submit" autocomplete="off" action="<?php echo e(route('other_banks.store')); ?>" enctype="multipart/form-data">
	<?php echo e(csrf_field()); ?>

	<div class="row px-2">
	    <div class="col-md-6">
			<div class="form-group">
				<label class="control-label"><?php echo e(_lang('Name')); ?></label>
				<input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required>
			</div>
		</div>

		<div class="col-md-6">
			<div class="form-group">
				<label class="control-label"><?php echo e(_lang('Swift Code')); ?></label>
				<input type="text" class="form-control" name="swift_code" value="<?php echo e(old('swift_code')); ?>" required>
			</div>
		</div>

		<div class="col-md-6">
			<div class="form-group">
				<label class="control-label"><?php echo e(_lang('Bank Country')); ?></label>
				<select class="form-control select2" name="bank_country" required>
					<?php echo e(get_country_list()); ?>

				</select>
			</div>
		</div>

		<div class="col-md-6">
			<div class="form-group">
				<label class="control-label"><?php echo e(_lang('Bank Currency')); ?></label>
				<select class="form-control select2" name="bank_currency" required>
					<?php echo e(create_option('currency','id','name','',array('status=' => 1))); ?>

				</select>
			</div>
		</div>

		<div class="col-md-6">
			<div class="form-group">
				<label class="control-label"><?php echo e(_lang('Minimum Transfer Amount')); ?></label>
				<input type="text" class="form-control" name="minimum_transfer_amount" value="<?php echo e(old('minimum_transfer_amount')); ?>" required>
			</div>
		</div>

		<div class="col-md-6">
			<div class="form-group">
				<label class="control-label"><?php echo e(_lang('Maximum Transfer Amount')); ?></label>
				<input type="text" class="form-control" name="maximum_transfer_amount" value="<?php echo e(old('maximum_transfer_amount')); ?>" required>
			</div>
		</div>

		<div class="col-md-6">
			<div class="form-group">
				<label class="control-label"><?php echo e(_lang('Fixed Charge')); ?></label>
				<input type="text" class="form-control" name="fixed_charge" value="<?php echo e(old('fixed_charge',0)); ?>" required>
			</div>
		</div>

		<div class="col-md-6">
			<div class="form-group">
				<label class="control-label"><?php echo e(_lang('Charge In Percentage')); ?></label>
				<div class="input-group mb-3">
					<input type="text" class="form-control" name="charge_in_percentage" value="<?php echo e(old('charge_in_percentage',0)); ?>" required>
					<div class="input-group-append">
						<span class="input-group-text">%</span>
					</div>
				</div>
			</div>
		</div>

		<div class="col-md-12">
			<div class="form-group">
				<label class="control-label"><?php echo e(_lang('Instructions')); ?></label>
				<textarea class="form-control" name="descriptions"><?php echo e(old('descriptions')); ?></textarea>
			</div>
		</div>

		<div class="col-md-12">
			<div class="form-group">
				<label class="control-label"><?php echo e(_lang('Status')); ?></label>
				<select class="form-control auto-select" data-selected="<?php echo e(old('status')); ?>" name="status"  required>
					<option value=""><?php echo e(_lang('Select One')); ?></option>
					<option value="1"><?php echo e(_lang('Active')); ?></option>
					<option value="0"><?php echo e(_lang('Deactivate')); ?></option>
				</select>
			</div>
		</div>


		<div class="col-md-12 mt-2">
		    <div class="form-group">
			    <button type="submit" class="btn btn-primary btn-lg"><i class="icofont-check-circled"></i> <?php echo e(_lang('Save')); ?></button>
		    </div>
		</div>
	</div>
</form>
<?php /**PATH /home/cbcholdi/public_html/bank/resources/views/backend/other_bank/modal/create.blade.php ENDPATH**/ ?>