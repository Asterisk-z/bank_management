<?php $__env->startComponent('mail::message'); ?>

<?php echo xss_clean($message); ?><br>

<?php echo e(_lang('Thanks')); ?>,<br>
<?php echo e(get_option('site_title', config('app.name'))); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH /home/cbcholdi/public_html/bank/resources/views/email/notification.blade.php ENDPATH**/ ?>